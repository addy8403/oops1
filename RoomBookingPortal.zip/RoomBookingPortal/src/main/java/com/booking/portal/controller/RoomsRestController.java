package com.booking.portal.controller;

import com.booking.portal.model.FilterRoomModel;
import com.booking.portal.model.RoomRequest;
import com.booking.portal.services.RoomRestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.w3c.dom.stylesheets.LinkStyle;

import java.util.List;

@RequestMapping("/rooms")
@RestController
public class RoomsRestController {

    @Autowired
    private RoomRestService roomRestService;

    @PostMapping
    public String addNewRoom(@RequestBody RoomRequest roomRequest){
        return roomRestService.addRoom(roomRequest);
    }

    @PatchMapping
    public String updateExistingRoom(@RequestBody RoomRequest roomRequest){
        return roomRestService.updateExistingRoom(roomRequest);
    }

    @DeleteMapping
    public String deleteRoom(@RequestParam long roomID){
        return roomRestService.deleteRoom(roomID);
    }

    @GetMapping
    public List<FilterRoomModel> filterRooms(@RequestParam(required = false) Long capacity ){
        return roomRestService.filterRooms(capacity);
    }
}
