package com.booking.portal.services;

import com.booking.portal.model.LoginRequest;
import com.booking.portal.model.SignupRequest;

public interface UserSecurityService {
    String loginUser(LoginRequest loginRequest);

    String sigupUser(SignupRequest signUpRequest);

}
