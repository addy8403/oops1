package com.booking.portal.controller;


import com.booking.portal.model.LoginRequest;
import com.booking.portal.model.PortalUserModel;
import com.booking.portal.model.SignupRequest;
import com.booking.portal.services.PortalUserService;
import com.booking.portal.services.UserSecurityService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class UserSecurityController {


    private final UserSecurityService userSecurityService;

    private final PortalUserService portalUserService;

    public UserSecurityController(UserSecurityService userSecurityService, PortalUserService portalUserService) {
        this.userSecurityService = userSecurityService;
        this.portalUserService = portalUserService;
    }

    @PostMapping("/login")
    public String loginUser(@RequestBody LoginRequest loginRequest)
    {
        return userSecurityService.loginUser(loginRequest);
    }

    @PostMapping("/signup")
    public String signupUser(@RequestBody SignupRequest signUpRequest) {
        return userSecurityService.sigupUser(signUpRequest);
    }

    @GetMapping("/users")
    public List<PortalUserModel> getAllPortalUsers(){
        return portalUserService.getAllPortalUsers();
    }
}
