package com.booking.portal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RoomBookingPortalApplication {

	public static void main(String[] args) {
		SpringApplication.run(RoomBookingPortalApplication.class, args);
	}

}
