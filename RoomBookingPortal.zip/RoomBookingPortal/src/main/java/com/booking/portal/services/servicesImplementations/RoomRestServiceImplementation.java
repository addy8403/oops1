package com.booking.portal.services.servicesImplementations;

import com.booking.portal.entity.Room;
import com.booking.portal.jpa.RoomRestRepository;
import com.booking.portal.model.BookRoomModel;
import com.booking.portal.model.FilterRoomModel;
import com.booking.portal.model.PortalUserModel;
import com.booking.portal.model.RoomRequest;
import com.booking.portal.services.RoomRestService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;
import org.springframework.web.server.ResponseStatusException;

import java.util.ArrayList;
import java.util.List;

@Service
public class RoomRestServiceImplementation implements RoomRestService {

    @Autowired
    private RoomRestRepository roomRestRepository;

    ObjectMapper objectMapper = new ObjectMapper();

    @Override
    public String addRoom(RoomRequest roomRequest) {

        roomRestRepository.findByRoomName(roomRequest.getRoomName()).ifPresent(room -> {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Room already exists");
        });

        if (roomRequest.getRoomCapacity() == 0)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid capacity");

        if (roomRequest.getRoomCapacity() < 0)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "invalid parameters");

        roomRestRepository.save(objectMapper.convertValue(roomRequest, Room.class));
        return "Room created successfully";
    }

    @Override
    public String updateExistingRoom(RoomRequest roomRequest) {

        roomRestRepository.findByRoomId(Math.toIntExact(roomRequest.getRoomID())).ifPresentOrElse(room -> {
            if (room.getRoomName().equalsIgnoreCase(roomRequest.getRoomName()))
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Room with given name exists");

            if (roomRequest.getRoomCapacity() == 0)
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid capacity");

            if (roomRequest.getRoomCapacity() < 0)
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "invalid parameters");

            room.setRoomName(roomRequest.getRoomName());
            room.setRoomCapacity(roomRequest.getRoomCapacity());

            roomRestRepository.save(room);
        }, () -> {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Room does not exist");
        });
        return "Room edited successfully";
    }

    @Override
    public String deleteRoom(long roomRequest) {
        roomRestRepository.findByRoomId(Math.toIntExact(roomRequest)).ifPresentOrElse(room -> {
            roomRestRepository.deleteById(Math.toIntExact(roomRequest));
        }, () -> {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Room does not exist");
        });
        return "Room deleted successfully";
    }

    @Override
    public List<FilterRoomModel> filterRooms(Long capacity) {
        List<Room> rooms = roomRestRepository.findAll();

        if(!ObjectUtils.isEmpty(capacity))
            rooms = rooms.stream().filter(room1 -> room1.getRoomCapacity().equals(capacity)).toList();

        List<FilterRoomModel> filterRoomModels = new ArrayList<>();
        if (!rooms.isEmpty()) {
            rooms.forEach(room -> {
                FilterRoomModel filterRoomModel = new FilterRoomModel();
                filterRoomModel.setRoomID(Long.valueOf(room.getRoomId()));
                filterRoomModel.setCapacity(room.getRoomCapacity());
                filterRoomModel.setRoomName(room.getRoomName());
                List<BookRoomModel> bookRoomModels = new ArrayList<>();
                room.getBookedRoom().forEach(bookRoom -> {
                    BookRoomModel bookRoomModel = new BookRoomModel();
                    bookRoomModel.setBookingID(bookRoom.getBookingId());
                    bookRoomModel.setDateOfBooking(bookRoom.getDateOfBooking());
                    bookRoomModel.setPurpose(bookRoom.getPurpose());
                    bookRoomModel.setTimeTo(String.valueOf(bookRoom.getTimeTo()));
                    bookRoomModel.setTimeFrom(String.valueOf(bookRoom.getTimeFrom()));
                    bookRoomModel.setPortalUser(PortalUserModel.builder().userID(room.getRoomId()).build());
                    bookRoomModels.add(bookRoomModel);
                });
                filterRoomModel.setBooked(bookRoomModels);
                filterRoomModels.add(filterRoomModel);
            });
        }
        return filterRoomModels;
    }
}
