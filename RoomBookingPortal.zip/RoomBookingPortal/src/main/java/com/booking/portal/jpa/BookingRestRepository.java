package com.booking.portal.jpa;

import com.booking.portal.entity.BookedRoom;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface BookingRestRepository extends JpaRepository<BookedRoom,Integer> {

    Optional<BookedRoom> findByBookingId(Integer roomId);

    void deleteByBookingId(Integer bookingId);

    List<BookedRoom> findAllByUserId(Integer userId);
}
