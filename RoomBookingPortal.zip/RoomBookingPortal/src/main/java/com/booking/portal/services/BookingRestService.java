package com.booking.portal.services;

import com.booking.portal.model.BookRoomModel;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public interface BookingRestService {

    String bookRoom(BookRoomModel bookRoomModel);


    String updateBookingRoom(BookRoomModel bookRoomModel);

    String deleteBooking(Integer bookingID);
}
