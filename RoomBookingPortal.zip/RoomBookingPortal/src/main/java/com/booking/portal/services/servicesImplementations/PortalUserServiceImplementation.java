package com.booking.portal.services.servicesImplementations;

import com.booking.portal.entity.BookedRoom;
import com.booking.portal.entity.PortalUser;
import com.booking.portal.jpa.BookingRestRepository;
import com.booking.portal.jpa.PortalUserRepository;
import com.booking.portal.model.PortalUserBookingModel;
import com.booking.portal.model.PortalUserModel;
import com.booking.portal.services.PortalUserService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
public class PortalUserServiceImplementation implements PortalUserService {

    @Autowired
    private PortalUserRepository portalUserRepository;

    @Autowired
    private BookingRestRepository bookingRestRepository;

    private final ObjectMapper objectMapper = new ObjectMapper();

    @Override
    public PortalUserModel getPortalUserById(int userID) {
        PortalUser portalUser = portalUserRepository.findByUseId(userID).orElseThrow(() -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "User does not exist"));
        PortalUserModel portalUserModel = new PortalUserModel();
        portalUserModel.setUserID(Math.toIntExact(portalUser.getUseId()));
        portalUserModel.setName(portalUser.getName());
        portalUserModel.setEmail(portalUser.getEmail());
        return portalUserModel;
    }

    @Override
    public List<PortalUserBookingModel> getUserHistory(int userId) {
        portalUserRepository.findByUseId(userId).orElseThrow(() -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "User does not exist"));
        List<BookedRoom> bookedRoomList = bookingRestRepository.findAllByUserId(userId);
        if (bookedRoomList.isEmpty()) throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "User does not exist");
        List<PortalUserBookingModel> portalUserBookingModels = new ArrayList<>();
        for (BookedRoom bookedRoom : bookedRoomList) {
            if (bookedRoom.getDateOfBooking().isBefore(LocalDate.now()) && bookedRoom.getTimeFrom().isBefore(LocalTime.now())) {
                PortalUserBookingModel portalUserBookingModel = new PortalUserBookingModel();
                portalUserBookingModel.setBookingId(bookedRoom.getBookingId());
                portalUserBookingModel.setDateOfBooking(bookedRoom.getDateOfBooking());
                portalUserBookingModel.setTimeFrom(String.valueOf(bookedRoom.getTimeFrom()));
                portalUserBookingModel.setTimeTo(String.valueOf(bookedRoom.getTimeTo()));
                portalUserBookingModel.setPurpose(bookedRoom.getPurpose());
                portalUserBookingModel.setRoom(bookedRoom.getRooms().getRoomName());
                portalUserBookingModel.setUserID(bookedRoom.getBookingId());
                portalUserBookingModels.add(portalUserBookingModel);
            }
        }
        return portalUserBookingModels;
    }

    @Override
    public PortalUserBookingModel getPortalUserUpcomingBooking(int userId) {
        portalUserRepository.findByUseId(userId).orElseThrow(() -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "User does not exist"));
        List<BookedRoom> bookedRoomList = bookingRestRepository.findAllByUserId(userId);
        Optional<BookedRoom> optionalBookedRoom = bookedRoomList.stream().filter(bookedRoom ->
                        bookedRoom.getDateOfBooking().isAfter(LocalDate.now().minusDays(1)))
                .reduce((room, bookedRoom2) -> {
                    if (room.getDateOfBooking().isBefore(bookedRoom2.getDateOfBooking()))
                        return room;
                    else return bookedRoom2;
                });
        PortalUserBookingModel portalUserBookingModel = new PortalUserBookingModel();
        if (optionalBookedRoom.isPresent()) {
            BookedRoom bookedRoom = optionalBookedRoom.get();
            portalUserBookingModel.setBookingId(bookedRoom.getBookingId());
            portalUserBookingModel.setDateOfBooking(bookedRoom.getDateOfBooking());
            portalUserBookingModel.setTimeFrom(String.valueOf(bookedRoom.getTimeFrom()));
            portalUserBookingModel.setTimeTo(String.valueOf(bookedRoom.getTimeTo()));
            portalUserBookingModel.setPurpose(bookedRoom.getPurpose());
            portalUserBookingModel.setRoom(bookedRoom.getRooms().getRoomName());
            portalUserBookingModel.setUserID(bookedRoom.getBookingId());
            return portalUserBookingModel;
        }
        return null;
    }

    @Override
    public List<PortalUserModel> getAllPortalUsers() {
        List<PortalUserModel> portalUserModels = new ArrayList<>();
        portalUserRepository.findAll().forEach(portalUser -> {
            PortalUserModel portalUserModel = new PortalUserModel();
            portalUserModel.setUserID(Math.toIntExact(portalUser.getUseId()));
            portalUserModel.setName(portalUser.getName());
            portalUserModel.setEmail(portalUser.getEmail());
            portalUserModels.add(portalUserModel);
        });
        return portalUserModels;
    }
}
