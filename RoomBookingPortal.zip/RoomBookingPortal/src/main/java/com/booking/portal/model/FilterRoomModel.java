package com.booking.portal.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class FilterRoomModel {
    private Long roomID;
    private Long capacity;
    private String roomName;
    private List<BookRoomModel> booked;
}
