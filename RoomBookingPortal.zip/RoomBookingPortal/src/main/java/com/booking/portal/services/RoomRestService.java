package com.booking.portal.services;

import com.booking.portal.model.FilterRoomModel;
import com.booking.portal.model.RoomRequest;
import org.springframework.http.ResponseEntity;

import java.util.List;

public interface RoomRestService {
    String addRoom(RoomRequest roomRequest);

    String updateExistingRoom(RoomRequest roomRequest);

    String deleteRoom(long roomID);

    List<FilterRoomModel> filterRooms(Long capacity);
}
