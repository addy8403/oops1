package com.booking.portal.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.Date;


@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class BookRoomModel {
    private int bookingID;
    private LocalDate dateOfBooking;
    private String timeFrom;
    private String timeTo;
    private String purpose;
    private Integer userID;
    private Integer roomID;
    private PortalUserModel portalUser;;

}
