package com.booking.portal.controller;

import com.booking.portal.model.BookRoomModel;
import com.booking.portal.services.BookingRestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/book")
public class BookingRestController {

    @Autowired
    private BookingRestService bookingRestService;

    @PostMapping
    public String bookRoom(@RequestBody BookRoomModel bookRoomModel){
        return bookingRestService.bookRoom(bookRoomModel);
    }

    @PatchMapping
    public String updateBookingRoom(@RequestBody BookRoomModel bookRoomModel){
        return bookingRestService.updateBookingRoom(bookRoomModel);
    }

    @DeleteMapping
    public String deleteBooking(@RequestParam Integer bookingID){
        return bookingRestService.deleteBooking(bookingID);
    }

}
