package com.booking.portal.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PortalUserBookingModel {
    private String room;
    private Integer userID;
    private Integer bookingId;
    private LocalDate dateOfBooking;
    private String timeFrom;
    private String timeTo;
    private String purpose;
}
