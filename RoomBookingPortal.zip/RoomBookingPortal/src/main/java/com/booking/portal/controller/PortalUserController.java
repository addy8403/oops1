package com.booking.portal.controller;


import com.booking.portal.model.PortalUserBookingModel;
import com.booking.portal.model.PortalUserModel;
import com.booking.portal.services.PortalUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class PortalUserController {

    @Autowired
    private PortalUserService portalUserService;

    @GetMapping("/user")
    public PortalUserModel getPortalUserById(@RequestParam Integer userID) {
        return portalUserService.getPortalUserById(userID);
    }

    @GetMapping("/history")
    public List<PortalUserBookingModel> getPortalUserHistory(@RequestParam int userID) {
        return portalUserService.getUserHistory(userID);
    }

    @GetMapping("/upcoming")
    public PortalUserBookingModel getPortalUserUpcomingBooking(@RequestParam int userID) {
        return portalUserService.getPortalUserUpcomingBooking(userID);
    }

}
