package com.booking.portal.handlers;

import com.booking.portal.model.ErrorModel;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.server.ResponseStatusException;

@RestControllerAdvice
public class CustomExceptions {

    @ExceptionHandler(ResponseStatusException.class)
    public ResponseEntity<?> getResponseStatusException(ResponseStatusException  exception){
        return new ResponseEntity<ErrorModel>(new ErrorModel(exception.getReason()), exception.getStatusCode());
    }

    @ExceptionHandler(BadCredentialsException.class)
    @ResponseStatus(HttpStatus.UNAUTHORIZED)
    public ErrorModel getBadCredentialsException(BadCredentialsException  badCredentialsException){
        badCredentialsException.getStackTrace();
        return new ErrorModel("Username/Password Incorrect");
    }

    @ExceptionHandler(CommonException.class)
    public ErrorModel getBadCredentialsException(CommonException  commonException){
        commonException.getStackTrace();
        return new ErrorModel(commonException.getMessage());
    }

}
