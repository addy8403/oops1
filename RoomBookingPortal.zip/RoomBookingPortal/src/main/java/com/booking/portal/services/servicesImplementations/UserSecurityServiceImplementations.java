package com.booking.portal.services.servicesImplementations;

import com.booking.portal.entity.PortalUser;
import com.booking.portal.jpa.PortalUserRepository;
import com.booking.portal.model.LoginRequest;
import com.booking.portal.model.SignupRequest;
import com.booking.portal.services.UserSecurityService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.server.ResponseStatusException;

@Service
public class UserSecurityServiceImplementations implements UserSecurityService {

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private PortalUserRepository portalUserRepository;

    @Autowired
    private  PasswordEncoder passwordEncoder;

    private ObjectMapper objectMapper = new ObjectMapper();

    @Override
    public String loginUser(LoginRequest loginRequest) {
        portalUserRepository.findByEmail(loginRequest.getEmail()).ifPresentOrElse(portalUser -> {
            Authentication authentication = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(loginRequest.getEmail(), loginRequest.getPassword()));
            SecurityContextHolder.getContext().setAuthentication(authentication);
        }, () -> {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "User does not exist");
        });
        return "Login Successful";
    }

    @Override
    public String sigupUser(SignupRequest signUpRequest) {
        portalUserRepository.findByEmail(signUpRequest.getEmail()).ifPresent(portalUser -> {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Forbidden, Account already exists");
        });
        PortalUser portalUser = objectMapper.convertValue(signUpRequest, PortalUser.class);
        portalUser.setPassword(passwordEncoder.encode(signUpRequest.getPassword()));
        if(!StringUtils.isEmpty(signUpRequest.getRole()))
            portalUser.setRole("USER");
        portalUserRepository.save(portalUser);
        return "Account Creation Successful";
    }
}
