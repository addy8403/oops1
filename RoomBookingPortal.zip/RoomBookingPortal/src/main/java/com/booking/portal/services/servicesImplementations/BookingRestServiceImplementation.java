package com.booking.portal.services.servicesImplementations;

import com.booking.portal.entity.BookedRoom;
import com.booking.portal.entity.Room;
import com.booking.portal.jpa.BookingRestRepository;
import com.booking.portal.jpa.PortalUserRepository;
import com.booking.portal.jpa.RoomRestRepository;
import com.booking.portal.model.BookRoomModel;
import com.booking.portal.services.BookingRestService;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Service
public class BookingRestServiceImplementation implements BookingRestService {

    @Autowired
    private PortalUserRepository portalUserRepository;

    @Autowired
    private BookingRestRepository bookingRestRepository;

    @Autowired
    private RoomRestRepository roomRestRepository;

    @Override
    public String bookRoom(BookRoomModel bookRoomModel) {
        LocalTime fromTime;
        LocalTime toTime;

        portalUserRepository.findByUseId(bookRoomModel.getUserID())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "User does not exist"));
        try {
            fromTime = LocalTime.parse(bookRoomModel.getTimeFrom(), DateTimeFormatter.ofPattern("HH:mm[:ss]"));
            toTime = LocalTime.parse(bookRoomModel.getTimeTo(), DateTimeFormatter.ofPattern("HH:mm[:ss]"));

            if (fromTime.isAfter(toTime) || (LocalDate.now().equals(bookRoomModel.getDateOfBooking()) && fromTime.isBefore(LocalTime.now()))) {
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid date/time");
            }

        } catch (ResponseStatusException e) {
            throw new ResponseStatusException(e.getStatusCode(), e.getReason());
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid date/time");
        }

        if (bookRoomModel.getDateOfBooking().isBefore(LocalDate.now()))
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid date/time");


        roomRestRepository.findByRoomId(bookRoomModel.getRoomID()).ifPresentOrElse(room -> {

            if (room.getBookedRoom() != null) {
                if (room.getBookedRoom()
                        .stream()
                        .anyMatch(bookedRoom -> {
                            boolean dateConflict = bookRoomModel.getDateOfBooking().isEqual(bookedRoom.getDateOfBooking());

                            boolean timeConflict = false;

                            if (dateConflict) {
                                timeConflict = (fromTime.isBefore(bookedRoom.getTimeTo()) ||
                                        bookedRoom.getTimeFrom().isBefore(fromTime)) &&
                                        (toTime.isAfter(bookedRoom.getTimeFrom()) ||
                                                bookedRoom.getTimeTo().isAfter(toTime));
                            }
                            return dateConflict && timeConflict;
                        })) {
                    throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Room does not exist");
                }
            }

        }, () -> {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Room does not exist");
        });

        BookedRoom bookedRoom = new BookedRoom();
        bookedRoom.setTimeFrom(fromTime);
        bookedRoom.setTimeTo(toTime);
        bookedRoom.setDateOfBooking(bookRoomModel.getDateOfBooking());
        bookedRoom.setPurpose(bookRoomModel.getPurpose());
        bookedRoom.setUserId(bookRoomModel.getUserID());
        Room rooms = roomRestRepository.findByRoomId(bookRoomModel.getRoomID()).get();
        bookedRoom.setRooms(rooms);
        bookingRestRepository.save(bookedRoom);
        return "Booking created successfully";
    }

    @Override
    public String updateBookingRoom(BookRoomModel bookRoomModel) {
        portalUserRepository.findByUseId(bookRoomModel.getUserID())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "User does not exist"));

        Room room = roomRestRepository.findByRoomId(bookRoomModel.getRoomID())
                .orElseThrow(() -> {
                    throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Room does not exist");
                });

        BookedRoom bookedRoom = bookingRestRepository.findByBookingId(bookRoomModel.getBookingID())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "Booking does not exist"));

        if (!(bookedRoom.getRooms().getRoomId().equals(bookRoomModel.getRoomID())))
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Booking does not exist");

        if (bookRoomModel.getDateOfBooking().isBefore(LocalDate.now()))
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid date/time");

        if (bookRoomModel.getDateOfBooking() != null)
            bookedRoom.setDateOfBooking(bookRoomModel.getDateOfBooking());
        if (bookRoomModel.getTimeFrom() != null)
            bookedRoom.setTimeFrom(LocalTime.parse(bookRoomModel.getTimeFrom(), DateTimeFormatter.ofPattern("HH:mm[:ss]")));
        if (bookRoomModel.getTimeTo() != null)
            bookedRoom.setTimeTo(LocalTime.parse(bookRoomModel.getTimeTo(), DateTimeFormatter.ofPattern("HH:mm[:ss]")));
        if (bookRoomModel.getPurpose() != null)
            bookedRoom.setPurpose(bookRoomModel.getPurpose());

        bookingRestRepository.save(bookedRoom);

        return "Booking modified successfully";
    }

    @Override
    @Transactional
    public String deleteBooking(Integer bookingID) {
        bookingRestRepository.findByBookingId(bookingID).ifPresentOrElse(bookedRoom -> {
            Room rooms = bookedRoom.getRooms();
            if (rooms.getBookedRoom().isEmpty())
                rooms.setBookedRoom(null);
            roomRestRepository.save(rooms);
            bookingRestRepository.deleteByBookingId(bookingID);
        }, () -> {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Booking does not exist");
        });
        return "Booking deleted successfully";
    }
}
