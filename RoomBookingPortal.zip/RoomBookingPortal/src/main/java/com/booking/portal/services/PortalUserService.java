package com.booking.portal.services;

import com.booking.portal.model.PortalUserBookingModel;
import com.booking.portal.model.PortalUserModel;

import java.util.List;

public interface PortalUserService {
    PortalUserModel getPortalUserById(int userId);

    List<PortalUserBookingModel> getUserHistory(int userId);

    PortalUserBookingModel getPortalUserUpcomingBooking(int userId);

    List<PortalUserModel> getAllPortalUsers();

}
