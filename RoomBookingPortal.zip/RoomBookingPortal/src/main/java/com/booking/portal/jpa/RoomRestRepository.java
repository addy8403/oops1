package com.booking.portal.jpa;

import com.booking.portal.entity.Room;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface RoomRestRepository extends JpaRepository<Room,Integer> {

    Optional<Room> findByRoomName(String  roomName);

    Optional<Room> findByRoomId(Integer roomId);

}
