package com.booking.portal.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RoomRequest {
    private Long userID;
    private Long roomID;
    private String roomName;
    private Long roomCapacity;
    private BookRoomModel bookedRoom;
}
